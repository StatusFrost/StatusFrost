// SAMPLE
this.i18n = {
    "settings": {
        "en": "Settings",
        "de": "Optionen"
    },
    "search": {
        "en": "Search",
        "de": "Suche"
    },
    "nothing-found": {
        "en": "No matches were found.",
        "de": "Keine Übereinstimmungen gefunden."
    },

    "information": {
        "en": "Information",
        "de": "Information"
    },
    "analytics": {
        "en": "Analytics",
        "de": "Abmeldung"
    },
    "enable": {
        "en": "Enable collection of anonymous statistics?",
        "de": "Aktivieren"
    },
    "disconnect": {
        "en": "Disconnect:",
        "de": "Trennen:"
    }
};
