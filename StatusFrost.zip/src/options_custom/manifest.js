// SAMPLE
this.manifest = {
    "name": "StatusFrost",
    "icon": "icon.png",
    "settings": [
        {
            "tab": i18n.get("Analytics"),
            "group": i18n.get("analytics"),
            "name": "cb_enableAnalytics",
            "type": "checkbox",
            "label": i18n.get("enable")
        },
    ]
};
