# StatusFrost
StatusFrost is a simple chrome extension that tracks personal browser usage statistics. Currently it tracks only a few metrics, but will hopefully provide extensive information to users on how they use the web in the future.
